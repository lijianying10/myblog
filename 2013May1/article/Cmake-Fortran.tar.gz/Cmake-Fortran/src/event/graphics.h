#include<iostream>
void testGraphics();

void singleLineoutput(int length ,double *datax, double *datay);
