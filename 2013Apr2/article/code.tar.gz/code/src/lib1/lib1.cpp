#include<iostream>
using namespace std;
int add(int a , int b)
{
	return a+b;
}
