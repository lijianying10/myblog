#include<iostream>
void testGraphics();
